SCS proceedings Latex style

The SCS proceedings style is usually adapted each year for different conferences. Thus you have to make sure that you are using the style for the current year.

The style comprises the following files which you should never change:

scsproc.sty
scsproc.bst
scspaperproc.cls
scsprocbib.tex

Note that the copyright notice *must* be properly set by the author. In case there are any questions about this, please contact your respective conference or symposium chair.
